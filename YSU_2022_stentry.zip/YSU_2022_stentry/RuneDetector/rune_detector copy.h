#ifndef RUNEDETECTOR_H
#define RUNEDETECTOR_H


class RuneDetector
{
public:
    RuneDetector();
};

#endif // RUNEDETECTOR_H
