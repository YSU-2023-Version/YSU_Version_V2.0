#ifndef CLASSIFY_H
#define CLASSIFY_H


class Classify
{
public:
    Classify();
};

#endif // CLASSIFY_H
